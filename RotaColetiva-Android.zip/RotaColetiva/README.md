# Rota Coletiva — MVP Android

Aplicativo colaborativo para entregadores, no espírito de um "Waze para entregadores".
O app **nunca** diz se um local é seguro ou perigoso — ele só organiza relatos enviados
pelos próprios entregadores e mostra estatísticas. A decisão é sempre do usuário.

## Como conseguir o APK (sem instalar nada)

Este projeto já vem com um workflow de GitHub Actions pronto (`.github/workflows/build-apk.yml`)
que compila um APK de debug na nuvem.

1. Crie um repositório no GitHub (pode ser privado) e suba esta pasta inteira nele.
2. Abra a aba **Actions** do repositório — o build começa sozinho.
3. Quando terminar (leva uns 3-5 minutos), abra a execução mais recente e baixe o
   artefato **`rota-coletiva-debug-apk`** — dentro dele está o `app-debug.apk`.
4. Transfira o APK pro celular (ou baixe direto pelo navegador do celular) e instale
   (é preciso permitir "instalar apps de fontes desconhecidas" para um APK de debug).

Alternativa: abra o projeto no Android Studio (Giraffe ou mais novo) e clique em
**Run ▶** com um emulador ou aparelho físico conectado — o próprio Android Studio
baixa o Gradle Wrapper e compila normalmente.

## Arquitetura

- **MVVM**: `ui/` (Activities/telas) → `viewmodel/` (estado e regras de apresentação)
  → `data/repository` (fonte única de verdade) → `data/local` (Room) / `data/remote` (preparado para backend futuro).
- **Mapa**: OSMDroid (OpenStreetMap), sem nenhuma dependência do Google Maps ou Play Services.
- **Localização**: `android.location.LocationManager` puro — de novo, sem Play Services.
- **Banco de dados**: Room (SQLite) local. Cada linha (`DeliveryReport`) tem um campo
  `synced: Boolean`, já pensado para um worker de sincronização futuro
  (veja `data/remote/RemoteSyncGateway.kt`).
- **Estatísticas**: `domain/StatsCalculator.kt` calcula os percentuais com **peso por
  recência** (um relato de hoje pesa mais que um de 3 meses atrás) e nunca produz um
  veredito — só números.
- **Geocodificação reversa**: `domain/ReverseGeocoder.kt` usa o Nominatim (OSM), não o
  Google Geocoding API.

## Fluxo implementado

`Login` → `Home (mapa + simular oferta)` → `Permissões` → `Oferta simulada (+ overlay real)`
→ `Detalhe pós-aceite` → `Avaliação (com anti-fraude por GPS)` → volta pra Home.

- **Overlay real**: `overlay/OverlayService.kt` desenha uma janela via `WindowManager`
  com `TYPE_APPLICATION_OVERLAY`, exigindo a permissão de sobreposição real do Android
  (`SYSTEM_ALERT_WINDOW` / "Exibir sobre outros apps").
- **Detecção automática**: `overlay/OfferAccessibilityService.kt` é um serviço de
  acessibilidade de verdade, registrado no Manifest e configurado em
  `res/xml/accessibility_service_config.xml`. Ele **não lê o conteúdo da tela** de
  nenhum app (`canRetrieveWindowContent="false"`) — só observa qual app está em
  primeiro plano, que é a mesma informação usada por apps de controle de tempo de tela.
  Nesta versão de MVP, a detecção do iFood é simulada: o botão "Simular oferta chegando"
  dispara o mesmo fluxo que a detecção automática dispararia.
- **Anti-fraude**: `viewmodel/RatingViewModel.kt` só permite enviar uma avaliação se
  o GPS atual do usuário estiver a até 400m do endereço da entrega **e** dentro de 1h
  desde que a corrida foi aceita — impedindo avaliações de locais nunca visitados ou
  feitas muito tempo depois.
- **Dados de exemplo**: no primeiro uso, `data/local/SeedData.kt` popula o banco com
  ~140 relatos sintéticos em 3 regiões do Rio de Janeiro, só para o mapa e as
  estatísticas não aparecerem vazios na primeira demonstração.

## Permissões solicitadas (todas reais, nenhuma decorativa)

| Permissão | Por quê |
|---|---|
| Localização (fina/aproximada) | saber a região atual e validar o anti-fraude |
| Sobreposição de tela | desenhar o painel de estatísticas por cima do app de entregas |
| Notificações | manter o serviço de monitoramento em primeiro plano (exigido no Android 13+) |
| Acessibilidade | detectar quando um app de entrega foi aberto |

## Limitações conhecidas deste MVP (e como evoluir)

- **Backend**: hoje é 100% local (Room). Para migrar, implemente
  `RemoteSyncGateway` (Firebase/Supabase/API própria) e troque a instância criada em
  `RotaColetivaApp.kt` — o schema já tem o campo `synced` pronto.
- **Localização em segundo plano**: o serviço de acessibilidade lê a localização
  independente do app estar em primeiro plano. Para publicar na Play Store (não
  necessário para este teste via sideload/APK de debug), o Google exige também a
  permissão `ACCESS_BACKGROUND_LOCATION` com uma tela de justificativa própria — não
  incluída aqui por não ser necessária para testar via APK direto.
- **Detecção do iFood**: o package real do iFood (`br.com.brainweb.ifood`) já está
  configurado em `OfferAccessibilityService`, mas como o app não lê o conteúdo da tela,
  ele reage à troca de app, não ao conteúdo específico da oferta — por isso a versão
  "real" e a simulada levam ao mesmo painel.
