# Keep Room entities and osmdroid classes (reflection-based)
-keep class com.rotacoletiva.app.data.local.entities.** { *; }
-keep class org.osmdroid.** { *; }
-dontwarn org.osmdroid.**
