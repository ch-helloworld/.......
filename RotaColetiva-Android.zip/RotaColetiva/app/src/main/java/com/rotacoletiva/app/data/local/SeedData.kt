package com.rotacoletiva.app.data.local

import com.rotacoletiva.app.data.local.entities.DeliveryReport
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import kotlin.random.Random

/**
 * Generates a plausible starting dataset so the map and HUD have something to show on a
 * fresh install, instead of an empty, unconvincing demo. All of this is clearly synthetic
 * seed data, inserted once (guarded by [com.rotacoletiva.app.util.PrefsManager.seeded]) -
 * every report a real user submits afterwards goes through the normal rating flow.
 */
object SeedData {

    private data class Cluster(val name: String, val lat: Double, val lon: Double, val count: Int)

    private val clusters = listOf(
        Cluster("Campinho", -22.8823, -43.3287, 60),
        Cluster("Praça Seca", -22.8974, -43.3346, 45),
        Cluster("Marechal Hermes", -22.8613, -43.3560, 35)
    )

    fun generate(seedUsername: String): List<DeliveryReport> {
        val random = Random(42)
        val now = System.currentTimeMillis()
        val reports = mutableListOf<DeliveryReport>()

        for (cluster in clusters) {
            repeat(cluster.count) {
                val jitterLat = (random.nextDouble() - 0.5) * 0.012
                val jitterLon = (random.nextDouble() - 0.5) * 0.012
                val ageHours = random.nextDouble() * 24 * 30 // spread across the last 30 days
                val occurrence = pickOccurrenceType(random)
                val rating = when (occurrence) {
                    OccurrenceType.CALM -> listOf(4, 5).random(random)
                    OccurrenceType.INSECURITY -> listOf(2, 3).random(random)
                    OccurrenceType.CONFRONTATION, OccurrenceType.THIRD_PARTY_APPROACH -> 1
                    else -> listOf(3, 4).random(random)
                }

                reports.add(
                    DeliveryReport(
                        latitude = cluster.lat + jitterLat,
                        longitude = cluster.lon + jitterLon,
                        timestampMillis = now - (ageHours * 3_600_000L).toLong(),
                        occurrenceType = occurrence,
                        deliveryRating = rating,
                        submittedBy = "seed_$seedUsername"
                    )
                )
            }
        }

        return reports
    }

    /** Weighted pick that mirrors the brief's own example numbers (~89% calm, single-digit others). */
    private fun pickOccurrenceType(random: Random): OccurrenceType {
        val roll = random.nextInt(100)
        return when {
            roll < 82 -> OccurrenceType.CALM
            roll < 90 -> OccurrenceType.INSECURITY
            roll < 93 -> OccurrenceType.THIRD_PARTY_APPROACH
            roll < 95 -> OccurrenceType.CONFRONTATION
            roll < 97 -> OccurrenceType.ACCESS_DIFFICULTY
            roll < 99 -> OccurrenceType.ACCESS_BLOCKED
            else -> OccurrenceType.POLICE_OPERATION
        }
    }
}
