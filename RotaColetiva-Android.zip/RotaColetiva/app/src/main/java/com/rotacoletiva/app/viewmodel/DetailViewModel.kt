package com.rotacoletiva.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import com.rotacoletiva.app.domain.RegionalStats
import com.rotacoletiva.app.domain.ReverseGeocoder
import kotlinx.coroutines.launch

class DetailViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as RotaColetivaApp).repository

    private val _stats = MutableLiveData<RegionalStats>()
    val stats: LiveData<RegionalStats> = _stats

    private val _categoryBreakdown = MutableLiveData<List<Pair<OccurrenceType, Int>>>()
    val categoryBreakdown: LiveData<List<Pair<OccurrenceType, Int>>> = _categoryBreakdown

    private val _address = MutableLiveData<ReverseGeocoder.Address>()
    val address: LiveData<ReverseGeocoder.Address> = _address

    fun load(preciseLatitude: Double, preciseLongitude: Double) {
        viewModelScope.launch {
            _stats.value = repository.getStatsNear(preciseLatitude, preciseLongitude, repository.preciseRadiusMeters)
            _categoryBreakdown.value = repository.getCategoryBreakdownNear(preciseLatitude, preciseLongitude, repository.preciseRadiusMeters)
            _address.value = ReverseGeocoder.reverseGeocode(preciseLatitude, preciseLongitude)
        }
    }
}
