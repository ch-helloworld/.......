package com.rotacoletiva.app.domain

import com.rotacoletiva.app.data.local.entities.DeliveryReport
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Turns a list of raw [DeliveryReport] rows into the [RegionalStats] shown on screen.
 *
 * Two rules encode the product's neutrality requirement:
 *  1. The output is only ever counts and percentages - never a verdict.
 *  2. More recent reports count more (half-life weighting), so a region's numbers
 *     reflect what is happening lately, not what happened six months ago.
 */
object StatsCalculator {

    /** A report's influence halves every 15 days. Recent reports dominate the percentages
     *  without old ones being erased outright - they just fade. */
    private const val HALF_LIFE_HOURS = 15 * 24.0

    fun compute(reports: List<DeliveryReport>, nowMillis: Long = System.currentTimeMillis()): RegionalStats {
        if (reports.isEmpty()) return RegionalStats.empty()

        var calmWeight = 0.0
        var insecurityWeight = 0.0
        var seriousWeight = 0.0
        var totalWeight = 0.0
        var lastReportMillis: Long? = null

        for (report in reports) {
            val hoursSince = (nowMillis - report.timestampMillis).coerceAtLeast(0) / 3_600_000.0
            val weight = 0.5.pow(hoursSince / HALF_LIFE_HOURS)
            totalWeight += weight

            when {
                report.occurrenceType.isCalm() -> calmWeight += weight
                report.occurrenceType.isSerious() -> seriousWeight += weight
                report.occurrenceType == OccurrenceType.INSECURITY -> insecurityWeight += weight
                else -> { /* neutral categories (police op, access blocked/difficulty) don't
                             feed the three headline percentages, but still count in totalWeight
                             and in the raw totalReports below */ }
            }

            if (lastReportMillis == null || report.timestampMillis > lastReportMillis) {
                lastReportMillis = report.timestampMillis
            }
        }

        fun pct(weight: Double) = if (totalWeight <= 0.0) 0 else ((weight / totalWeight) * 100).roundToInt()

        return RegionalStats(
            totalReports = reports.size,
            pctCalm = pct(calmWeight),
            pctInsecurity = pct(insecurityWeight),
            pctSerious = pct(seriousWeight),
            lastReportMillis = lastReportMillis,
            confidence = ConfidenceLevel.fromSampleSize(reports.size)
        )
    }

    /** Per-category percentages (used on the detail screen's category breakdown), also recency-weighted. */
    fun computeCategoryBreakdown(reports: List<DeliveryReport>, nowMillis: Long = System.currentTimeMillis()): List<Pair<OccurrenceType, Int>> {
        if (reports.isEmpty()) return emptyList()
        val weights = LinkedHashMap<OccurrenceType, Double>()
        var totalWeight = 0.0

        for (report in reports) {
            val hoursSince = (nowMillis - report.timestampMillis).coerceAtLeast(0) / 3_600_000.0
            val weight = 0.5.pow(hoursSince / HALF_LIFE_HOURS)
            weights[report.occurrenceType] = (weights[report.occurrenceType] ?: 0.0) + weight
            totalWeight += weight
        }

        if (totalWeight <= 0.0) return emptyList()

        return weights.entries
            .map { (type, weight) -> type to ((weight / totalWeight) * 100).roundToInt() }
            .sortedByDescending { it.second }
    }
}
