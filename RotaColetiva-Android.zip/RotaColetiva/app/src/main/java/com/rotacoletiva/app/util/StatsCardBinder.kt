package com.rotacoletiva.app.util

import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import com.rotacoletiva.app.R
import com.rotacoletiva.app.domain.ConfidenceLevel
import com.rotacoletiva.app.domain.RegionalStats

/**
 * Fills the fields of an inflated `view_stats_card.xml` with real numbers.
 * Kept as a single, framework-agnostic function so both an Activity and a plain
 * WindowManager-added View (the overlay) can reuse the exact same rendering logic.
 */
object StatsCardBinder {

    fun showScanning(cardRoot: View) {
        cardRoot.findViewById<View>(R.id.scanGroup).visibility = View.VISIBLE
        cardRoot.findViewById<View>(R.id.bodyGroup).visibility = View.GONE
    }

    fun bind(cardRoot: View, regionLabel: String, stats: RegionalStats) {
        cardRoot.findViewById<View>(R.id.scanGroup).visibility = View.GONE
        val body = cardRoot.findViewById<View>(R.id.bodyGroup)
        body.visibility = View.VISIBLE

        cardRoot.findViewById<TextView>(R.id.textRegion).text = "📍 $regionLabel"

        if (stats.totalReports == 0) {
            cardRoot.findViewById<TextView>(R.id.textTotalReports).text =
                cardRoot.context.getString(R.string.hud_no_data)
        } else {
            cardRoot.findViewById<TextView>(R.id.textTotalReports).text =
                cardRoot.context.getString(R.string.hud_total_reports, stats.totalReports)
        }

        cardRoot.findViewById<TextView>(R.id.textCalmPct).text = "${stats.pctCalm}%"
        cardRoot.findViewById<ProgressBar>(R.id.barCalm).progress = stats.pctCalm

        cardRoot.findViewById<TextView>(R.id.textInsecurityPct).text = "${stats.pctInsecurity}%"
        cardRoot.findViewById<ProgressBar>(R.id.barInsecurity).progress = stats.pctInsecurity

        cardRoot.findViewById<TextView>(R.id.textSeriousPct).text = "${stats.pctSerious}%"
        cardRoot.findViewById<ProgressBar>(R.id.barSerious).progress = stats.pctSerious

        cardRoot.findViewById<TextView>(R.id.textLastReport).text = if (stats.lastReportMillis != null) {
            cardRoot.context.getString(R.string.hud_last_report, TimeFormat.relative(stats.lastReportMillis))
        } else {
            ""
        }

        val segments = listOf(R.id.confSeg1, R.id.confSeg2, R.id.confSeg3)
        segments.forEachIndexed { index, id ->
            val on = index < stats.confidence.segmentsFilled
            cardRoot.findViewById<View>(id).setBackgroundResource(
                if (on) R.drawable.bg_conf_segment_on else R.drawable.bg_conf_segment_off
            )
        }

        val confidenceLabel = when (stats.confidence) {
            ConfidenceLevel.LOW -> R.string.confidence_low
            ConfidenceLevel.MEDIUM -> R.string.confidence_medium
            ConfidenceLevel.HIGH -> R.string.confidence_high
        }
        cardRoot.findViewById<TextView>(R.id.textConfidenceLabel).setText(confidenceLabel)
    }
}
