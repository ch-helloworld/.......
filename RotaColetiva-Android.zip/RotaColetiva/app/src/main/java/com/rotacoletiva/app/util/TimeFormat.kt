package com.rotacoletiva.app.util

object TimeFormat {

    /** Formats a past timestamp as a short relative string, e.g. "há 18 min", "há 3h", "há 2 dias". */
    fun relative(pastMillis: Long, nowMillis: Long = System.currentTimeMillis()): String {
        val diffMinutes = ((nowMillis - pastMillis).coerceAtLeast(0)) / 60_000L
        return when {
            diffMinutes < 1 -> "agora mesmo"
            diffMinutes < 60 -> "há $diffMinutes min"
            diffMinutes < 60 * 24 -> "há ${diffMinutes / 60}h"
            else -> "há ${diffMinutes / (60 * 24)} dias"
        }
    }
}
