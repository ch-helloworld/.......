package com.rotacoletiva.app.domain

/**
 * How much a statistic should be trusted, based purely on how many reports back it up.
 * This never reflects how "safe" a place is - only how many people contributed data,
 * which is the honest thing the app can claim to know.
 */
enum class ConfidenceLevel(val segmentsFilled: Int) {
    LOW(1),
    MEDIUM(2),
    HIGH(3);

    companion object {
        /** Thresholds are intentionally conservative: a handful of reports should never
         *  be presented with the same weight as a well-sampled region. */
        fun fromSampleSize(count: Int): ConfidenceLevel = when {
            count >= 150 -> HIGH
            count >= 30 -> MEDIUM
            else -> LOW
        }
    }
}
