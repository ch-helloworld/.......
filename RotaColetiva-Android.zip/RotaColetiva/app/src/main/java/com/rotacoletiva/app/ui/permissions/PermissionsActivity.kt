package com.rotacoletiva.app.ui.permissions

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.rotacoletiva.app.R
import com.rotacoletiva.app.databinding.ActivityPermissionsBinding
import com.rotacoletiva.app.databinding.ItemPermissionBinding
import com.rotacoletiva.app.overlay.OfferAccessibilityService
import com.rotacoletiva.app.util.PermissionUtils

class PermissionsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPermissionsBinding

    private val locationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { refreshAll() }

    private val notificationLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { refreshAll() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPermissionsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupLocationRow()
        setupOverlayRow()
        setupNotificationsRow()
        setupAccessibilityRow()

        binding.buttonDone.setOnClickListener { finish() }
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    private fun setupLocationRow() {
        val row = ItemPermissionBinding.bind(binding.rowLocation.root)
        row.permTitle.text = getString(R.string.perm_location_title)
        row.permDescription.text = getString(R.string.perm_location_desc)
        row.permAction.text = getString(R.string.perm_grant)
        row.permAction.setOnClickListener {
            locationLauncher.launch(
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
            )
        }
    }

    private fun setupOverlayRow() {
        val row = ItemPermissionBinding.bind(binding.rowOverlay.root)
        row.permTitle.text = getString(R.string.perm_overlay_title)
        row.permDescription.text = getString(R.string.perm_overlay_desc)
        row.permAction.text = getString(R.string.perm_open_settings)
        row.permAction.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun setupNotificationsRow() {
        val row = ItemPermissionBinding.bind(binding.rowNotifications.root)
        row.permTitle.text = getString(R.string.perm_notifications_title)
        row.permDescription.text = getString(R.string.perm_notifications_desc)
        row.permAction.text = getString(R.string.perm_grant)
        row.permAction.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun setupAccessibilityRow() {
        val row = ItemPermissionBinding.bind(binding.rowAccessibility.root)
        row.permTitle.text = getString(R.string.perm_accessibility_title)
        row.permDescription.text = getString(R.string.perm_accessibility_desc)
        row.permAction.text = getString(R.string.perm_open_settings)
        row.permAction.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    private fun refreshAll() {
        updateRow(
            ItemPermissionBinding.bind(binding.rowLocation.root),
            PermissionUtils.hasLocationPermission(this)
        )
        updateRow(
            ItemPermissionBinding.bind(binding.rowOverlay.root),
            PermissionUtils.hasOverlayPermission(this)
        )
        updateRow(
            ItemPermissionBinding.bind(binding.rowNotifications.root),
            PermissionUtils.hasNotificationPermission(this)
        )
        updateRow(
            ItemPermissionBinding.bind(binding.rowAccessibility.root),
            PermissionUtils.isAccessibilityServiceEnabled(this, OfferAccessibilityService::class.java.name)
        )
    }

    private fun updateRow(row: ItemPermissionBinding, granted: Boolean) {
        row.permStatus.text = if (granted) getString(R.string.perm_granted) else ""
        row.permAction.isEnabled = !granted
        row.permAction.alpha = if (granted) 0.4f else 1f
    }
}
