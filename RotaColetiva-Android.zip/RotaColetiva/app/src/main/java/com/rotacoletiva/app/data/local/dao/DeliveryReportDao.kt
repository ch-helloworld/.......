package com.rotacoletiva.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.rotacoletiva.app.data.local.entities.DeliveryReport

@Dao
interface DeliveryReportDao {

    @Insert
    suspend fun insert(report: DeliveryReport): Long

    /**
     * SQLite has no trigonometric functions, so exact-radius filtering can't be expressed
     * in SQL. This query does the cheap part (a rectangular pre-filter using plain
     * comparisons, which the lat/lon indices can use); the repository then applies the
     * precise Haversine distance check in Kotlin on this much smaller candidate set.
     */
    @Query(
        """
        SELECT * FROM delivery_reports
        WHERE latitude BETWEEN :minLat AND :maxLat
        AND longitude BETWEEN :minLon AND :maxLon
        ORDER BY timestampMillis DESC
        """
    )
    suspend fun getInBoundingBox(minLat: Double, maxLat: Double, minLon: Double, maxLon: Double): List<DeliveryReport>

    @Query("SELECT * FROM delivery_reports ORDER BY timestampMillis DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<DeliveryReport>

    @Query("SELECT * FROM delivery_reports WHERE submittedBy = :username ORDER BY timestampMillis DESC LIMIT :limit")
    suspend fun getBySubmitter(username: String, limit: Int): List<DeliveryReport>

    @Query("SELECT * FROM delivery_reports WHERE synced = 0")
    suspend fun getUnsynced(): List<DeliveryReport>

    @Query("SELECT COUNT(*) FROM delivery_reports")
    suspend fun count(): Int
}
