package com.rotacoletiva.app.overlay

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.view.accessibility.AccessibilityEvent
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.location.LocationHelper
import com.rotacoletiva.app.util.PermissionUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Watches for foreground-app changes so the app can react automatically when a delivery
 * platform is opened - without reading anything from that app's screen
 * (`canRetrieveWindowContent="false"` in the service config, and this class never calls
 * `event.source` or inspects the node tree). It only ever looks at [AccessibilityEvent.getPackageName],
 * which is the same information the system already exposes to every foreground-app-aware
 * accessibility tool (screen-time trackers, app blockers, etc).
 *
 * On a real device this would list iFood's actual package name; this MVP also matches its
 * own package so a tester without iFood installed can still see the automatic trigger by
 * switching briefly to any other app and back.
 */
class OfferAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private var lastPackage: String? = null

    private val monitoredPackages = setOf(
        "br.com.brainweb.ifood",
        SELF_PACKAGE
    )

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in monitoredPackages) return

        // Avoid triggering on our own app's normal navigation - only react when returning
        // from elsewhere, not on every internal screen change.
        if (pkg == SELF_PACKAGE && lastPackage == SELF_PACKAGE) return
        lastPackage = pkg

        triggerOverlayForCurrentLocation()
    }

    private fun triggerOverlayForCurrentLocation() {
        if (!PermissionUtils.hasOverlayPermission(this)) return

        scope.launch {
            val location = LocationHelper(this@OfferAccessibilityService).getCurrentLocation() ?: return@launch
            val repository = (application as RotaColetivaApp).repository
            startService(
                OverlayService.showIntent(
                    this@OfferAccessibilityService,
                    location.latitude,
                    location.longitude,
                    repository.regionalRadiusMeters
                )
            )
        }
    }

    override fun onInterrupt() { /* Required override; nothing to clean up. */ }

    companion object {
        private const val SELF_PACKAGE = "com.rotacoletiva.app"

        fun componentName(packageName: String) = ComponentName(packageName, OfferAccessibilityService::class.java.name)
    }
}
