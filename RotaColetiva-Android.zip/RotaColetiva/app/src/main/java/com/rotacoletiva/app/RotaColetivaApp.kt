package com.rotacoletiva.app

import android.app.Application
import androidx.preference.PreferenceManager
import com.rotacoletiva.app.data.local.AppDatabase
import com.rotacoletiva.app.data.local.SeedData
import com.rotacoletiva.app.data.remote.NoOpRemoteSyncGateway
import com.rotacoletiva.app.data.repository.DeliveryRepository
import com.rotacoletiva.app.util.PrefsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration

class RotaColetivaApp : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var repository: DeliveryRepository
        private set

    lateinit var prefsManager: PrefsManager
        private set

    override fun onCreate() {
        super.onCreate()

        // OSMDroid requires a user agent and a writable cache path to be configured once,
        // before any MapView is created, or tile downloads will be silently rejected.
        Configuration.getInstance().load(this, PreferenceManager.getDefaultSharedPreferences(this))
        Configuration.getInstance().userAgentValue = packageName

        prefsManager = PrefsManager(this)

        val dao = AppDatabase.getInstance(this).deliveryReportDao()
        repository = DeliveryRepository(dao, NoOpRemoteSyncGateway())

        seedDatabaseIfNeeded()
    }

    private fun seedDatabaseIfNeeded() {
        if (prefsManager.seeded) return
        applicationScope.launch {
            if (repository.reportCount() == 0) {
                SeedData.generate(seedUsername = "demo").forEach { report ->
                    repository.submitReport(
                        latitude = report.latitude,
                        longitude = report.longitude,
                        occurrenceType = report.occurrenceType,
                        deliveryRating = report.deliveryRating,
                        submittedBy = report.submittedBy
                    )
                }
            }
            prefsManager.seeded = true
        }
    }
}
