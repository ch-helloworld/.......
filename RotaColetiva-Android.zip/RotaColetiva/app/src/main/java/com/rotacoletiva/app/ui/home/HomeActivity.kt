package com.rotacoletiva.app.ui.home

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.rotacoletiva.app.R
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.data.local.entities.DeliveryReport
import com.rotacoletiva.app.databinding.ActivityHomeBinding
import com.rotacoletiva.app.overlay.OfferAccessibilityService
import com.rotacoletiva.app.ui.offer.OfferActivity
import com.rotacoletiva.app.ui.permissions.PermissionsActivity
import com.rotacoletiva.app.util.PermissionUtils
import com.rotacoletiva.app.util.RegionNamer
import com.rotacoletiva.app.util.StatsCardBinder
import com.rotacoletiva.app.viewmodel.HomeViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker

class HomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityHomeBinding
    private lateinit var viewModel: HomeViewModel

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Result observed again in onResume; nothing extra to do here. */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = (application as RotaColetivaApp).prefsManager
        if (!prefs.isLoggedIn()) {
            startActivity(Intent(this, com.rotacoletiva.app.ui.login.LoginActivity::class.java))
            finish()
            return
        }

        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[HomeViewModel::class.java]

        setupMap()
        setupButtons()
        requestBasicPermissionsIfNeeded()

        viewModel.mapReports.observe(this) { reports -> plotMarkers(reports) }
        viewModel.selectedRegionStats.observe(this) { stats ->
            if (stats == null) {
                binding.regionStatsCardContainer.visibility = View.GONE
            } else {
                val card = binding.regionStatsCardContainer.getChildAt(0)
                StatsCardBinder.bind(card, currentRegionLabel, stats)
            }
        }
    }

    private var currentRegionLabel: String = ""

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
        viewModel.loadMapReports()
        refreshStatusText()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
    }

    private fun refreshStatusText() {
        val monitoring = PermissionUtils.isAccessibilityServiceEnabled(
            this, OfferAccessibilityService::class.java.name
        )
        binding.textStatus.text = getString(
            if (monitoring) R.string.home_status_monitoring else R.string.home_status_idle
        )
    }

    private fun setupMap() {
        Configuration.getInstance().userAgentValue = packageName
        binding.mapView.setTileSource(TileSourceFactory.MAPNIK)
        binding.mapView.setMultiTouchControls(true)
        binding.mapView.controller.setZoom(13.5)
        // Center over the seeded Rio de Janeiro neighborhoods so the demo data is visible immediately.
        binding.mapView.controller.setCenter(GeoPoint(-22.8850, -43.3380))
    }

    private fun setupButtons() {
        binding.buttonPermissions.setOnClickListener {
            startActivity(Intent(this, PermissionsActivity::class.java))
        }
        binding.buttonSimulateOffer.setOnClickListener {
            startActivity(Intent(this, OfferActivity::class.java))
        }
        binding.buttonCloseStatsCard.setOnClickListener {
            viewModel.clearSelection()
        }
    }

    private fun plotMarkers(reports: List<DeliveryReport>) {
        binding.mapView.overlays.clear()
        for (report in reports) {
            val marker = Marker(binding.mapView)
            marker.position = GeoPoint(report.latitude, report.longitude)
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            marker.setOnMarkerClickListener { _, _ ->
                onMarkerTapped(report.latitude, report.longitude)
                true
            }
            binding.mapView.overlays.add(marker)
        }
        binding.mapView.invalidate()
    }

    private fun onMarkerTapped(latitude: Double, longitude: Double) {
        currentRegionLabel = RegionNamer.nameFor(latitude, longitude)
        binding.regionStatsCardContainer.visibility = View.VISIBLE
        val card = binding.regionStatsCardContainer.getChildAt(0)
        StatsCardBinder.showScanning(card)
        viewModel.loadStatsForMarker(latitude, longitude)
    }

    private fun requestBasicPermissionsIfNeeded() {
        val toRequest = mutableListOf<String>()
        if (!PermissionUtils.hasLocationPermission(this)) {
            toRequest += Manifest.permission.ACCESS_FINE_LOCATION
            toRequest += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU &&
            !PermissionUtils.hasNotificationPermission(this)
        ) {
            toRequest += Manifest.permission.POST_NOTIFICATIONS
        }
        if (toRequest.isNotEmpty()) {
            permissionLauncher.launch(toRequest.toTypedArray())
        }
    }
}
