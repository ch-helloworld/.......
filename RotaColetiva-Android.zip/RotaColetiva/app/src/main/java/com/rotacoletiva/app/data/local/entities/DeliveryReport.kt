package com.rotacoletiva.app.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * A single georeferenced report submitted by a delivery driver after finishing a delivery.
 *
 * This is the row-level unit that feeds every aggregate statistic shown in the app.
 * The `synced` flag exists so a future remote backend (Firebase/Supabase/own API) can be
 * plugged in later: a sync worker would simply query `getUnsynced()` and flip this flag
 * once each row is confirmed uploaded, without needing any schema change.
 */
@Entity(tableName = "delivery_reports")
data class DeliveryReport(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val latitude: Double,
    val longitude: Double,

    /** Epoch millis of when the report was submitted. Used both for display and for the
     *  time-decay weighting applied when computing statistics (recent reports count more). */
    val timestampMillis: Long,

    val occurrenceType: OccurrenceType,

    /** Star rating for the delivery, 1..5. */
    val deliveryRating: Int,

    /** Local username that submitted this report (fictitious login, stored for the user's own history list). */
    val submittedBy: String,

    /** Whether this row has been pushed to a remote backend. Always false in this MVP,
     *  which only persists locally, but kept so a future sync layer has somewhere to write. */
    val synced: Boolean = false
)
