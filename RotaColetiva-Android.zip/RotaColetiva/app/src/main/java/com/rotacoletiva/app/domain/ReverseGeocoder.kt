package com.rotacoletiva.app.domain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Turns a coordinate into a human-readable street address using OpenStreetMap's free
 * Nominatim reverse-geocoding endpoint - keeping the whole map/geocoding stack OSM-based,
 * with no Google API involved anywhere.
 *
 * Nominatim's usage policy requires a descriptive User-Agent and at most ~1 request/second,
 * both respected here since this is called at most once per delivery acceptance.
 */
object ReverseGeocoder {

    data class Address(val label: String, val neighborhood: String?)

    suspend fun reverseGeocode(latitude: Double, longitude: Double): Address = withContext(Dispatchers.IO) {
        try {
            val url = URL(
                "https://nominatim.openstreetmap.org/reverse?format=json&lat=$latitude&lon=$longitude&zoom=18&addressdetails=1"
            )
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "RotaColetiva-MVP/1.0 (contato@example.com)")
                connectTimeout = 6_000
                readTimeout = 6_000
            }

            val body = connection.inputStream.bufferedReader().use { it.readText() }
            connection.disconnect()

            val json = JSONObject(body)
            val address = json.optJSONObject("address")
            val road = address?.optString("road").takeUnless { it.isNullOrBlank() }
            val houseNumber = address?.optString("house_number").takeUnless { it.isNullOrBlank() }
            val neighborhood = address?.optString("suburb")?.takeUnless { it.isNullOrBlank() }
                ?: address?.optString("neighbourhood")?.takeUnless { it.isNullOrBlank() }

            val label = when {
                road != null && houseNumber != null -> "$road, $houseNumber"
                road != null -> road
                else -> json.optString("display_name").ifBlank { "Endereço não identificado" }
            }

            Address(label = label, neighborhood = neighborhood)
        } catch (e: Exception) {
            // Offline, DNS failure, rate-limited, etc. The screen must still work using the
            // coordinate and the locally-known region name - never crash on a network hiccup.
            Address(label = "Endereço não identificado", neighborhood = null)
        }
    }
}
