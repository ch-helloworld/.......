package com.rotacoletiva.app.data.local.entities

/**
 * The fixed set of categories a delivery driver can attach to a report.
 * Deliberately closed (no free text) to avoid moderation and legal exposure,
 * as required by the product brief.
 */
enum class OccurrenceType {
    CALM,
    INSECURITY,
    THIRD_PARTY_APPROACH,
    CONFRONTATION,
    POLICE_OPERATION,
    ACCESS_BLOCKED,
    ACCESS_DIFFICULTY;

    /** Whether this category counts as a "serious occurrence" for the HUD's headline stat. */
    fun isSerious(): Boolean = this == CONFRONTATION || this == THIRD_PARTY_APPROACH

    /** Whether this category counts as "no occurrence" for the HUD's headline stat. */
    fun isCalm(): Boolean = this == CALM
}
