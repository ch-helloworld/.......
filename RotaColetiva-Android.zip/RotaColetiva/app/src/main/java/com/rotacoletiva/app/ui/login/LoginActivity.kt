package com.rotacoletiva.app.ui.login

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.databinding.ActivityLoginBinding
import com.rotacoletiva.app.ui.home.HomeActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val prefs = (application as RotaColetivaApp).prefsManager
        if (prefs.isLoggedIn()) {
            goToHome()
            return
        }

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.buttonLogin.setOnClickListener {
            val name = binding.editUsername.text?.toString()?.trim().orEmpty()
            if (name.isEmpty()) {
                binding.textError.visibility = android.view.View.VISIBLE
                return@setOnClickListener
            }
            prefs.username = name
            goToHome()
        }
    }

    private fun goToHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }
}
