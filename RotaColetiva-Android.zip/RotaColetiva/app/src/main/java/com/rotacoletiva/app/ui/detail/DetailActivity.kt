package com.rotacoletiva.app.ui.detail

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.rotacoletiva.app.R
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import com.rotacoletiva.app.databinding.ActivityDetailBinding
import com.rotacoletiva.app.databinding.ItemCategoryBarBinding
import com.rotacoletiva.app.domain.ConfidenceLevel
import com.rotacoletiva.app.overlay.OverlayService
import com.rotacoletiva.app.ui.home.HomeActivity
import com.rotacoletiva.app.ui.rating.RatingActivity
import com.rotacoletiva.app.util.CircleGeometry
import com.rotacoletiva.app.util.IntentKeys
import com.rotacoletiva.app.util.TimeFormat
import com.rotacoletiva.app.viewmodel.DetailViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding
    private lateinit var viewModel: DetailViewModel

    private var preciseLat = 0.0
    private var preciseLon = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Making sure the overlay HUD from the offer screen is gone once the driver has
        // moved on to this precise view.
        startService(OverlayService.hideIntent(this))

        preciseLat = intent.getDoubleExtra(IntentKeys.EXTRA_PRECISE_LATITUDE, Double.NaN)
        preciseLon = intent.getDoubleExtra(IntentKeys.EXTRA_PRECISE_LONGITUDE, Double.NaN)
        if (preciseLat.isNaN() || preciseLon.isNaN()) {
            finish()
            return
        }

        viewModel = ViewModelProvider(this)[DetailViewModel::class.java]

        setupMap()
        setupButtons()
        observeViewModel()

        viewModel.load(preciseLat, preciseLon)
    }

    override fun onResume() {
        super.onResume()
        binding.detailMapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.detailMapView.onPause()
    }

    private fun setupMap() {
        Configuration.getInstance().userAgentValue = packageName
        binding.detailMapView.setTileSource(TileSourceFactory.MAPNIK)
        binding.detailMapView.setMultiTouchControls(false)
        binding.detailMapView.controller.setZoom(17.0)
        val center = GeoPoint(preciseLat, preciseLon)
        binding.detailMapView.controller.setCenter(center)

        val repository = (application as RotaColetivaApp).repository
        val circle = Polygon().apply {
            points = CircleGeometry.circlePoints(preciseLat, preciseLon, repository.preciseRadiusMeters)
            fillColor = android.graphics.Color.parseColor("#33F2A93B") // translucent amber, consistent with the app's neutral palette
            strokeColor = android.graphics.Color.parseColor("#803A2F14")
            strokeWidth = 2f
        }
        binding.detailMapView.overlays.add(circle)

        val marker = Marker(binding.detailMapView).apply {
            position = center
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        binding.detailMapView.overlays.add(marker)
        binding.detailMapView.invalidate()
    }

    private fun setupButtons() {
        binding.buttonBack.setOnClickListener { goHome() }
        binding.buttonCancel.setOnClickListener { goHome() }
        binding.buttonContinue.setOnClickListener {
            val intent = Intent(this, RatingActivity::class.java).apply {
                putExtra(IntentKeys.EXTRA_PRECISE_LATITUDE, preciseLat)
                putExtra(IntentKeys.EXTRA_PRECISE_LONGITUDE, preciseLon)
                putExtra(IntentKeys.EXTRA_DELIVERY_STARTED_AT, System.currentTimeMillis())
            }
            startActivity(intent)
            finish()
        }
    }

    private fun goHome() {
        startActivity(Intent(this, HomeActivity::class.java))
        finish()
    }

    private fun observeViewModel() {
        viewModel.address.observe(this) { address ->
            binding.textAddress.text = address.label
        }

        viewModel.stats.observe(this) { stats ->
            binding.kpiReports.text = stats.totalReports.toString()
            binding.kpiConfidence.text = when (stats.confidence) {
                ConfidenceLevel.LOW -> getString(R.string.confidence_low)
                ConfidenceLevel.MEDIUM -> getString(R.string.confidence_medium)
                ConfidenceLevel.HIGH -> getString(R.string.confidence_high)
            }
            binding.kpiLastReport.text = stats.lastReportMillis?.let { TimeFormat.relative(it) } ?: "-"

            val updatedText = stats.lastReportMillis?.let { TimeFormat.relative(it) } ?: getString(R.string.hud_no_data)
            binding.textAddressSub.text = getString(R.string.detail_subtitle, updatedText)
        }

        viewModel.categoryBreakdown.observe(this) { breakdown -> renderCategoryBreakdown(breakdown) }
    }

    private fun renderCategoryBreakdown(breakdown: List<Pair<OccurrenceType, Int>>) {
        binding.categoryContainer.removeAllViews()
        for ((type, pct) in breakdown) {
            val row = ItemCategoryBarBinding.inflate(LayoutInflater.from(this), binding.categoryContainer, true)
            row.categoryLabel.text = labelFor(type)
            row.categoryPct.text = "$pct%"
            row.categoryBar.progress = pct
        }
    }

    private fun labelFor(type: OccurrenceType): String = when (type) {
        OccurrenceType.CALM -> getString(R.string.cat_calm)
        OccurrenceType.INSECURITY -> getString(R.string.cat_insecurity)
        OccurrenceType.THIRD_PARTY_APPROACH -> getString(R.string.cat_approach)
        OccurrenceType.CONFRONTATION -> getString(R.string.cat_confrontation)
        OccurrenceType.POLICE_OPERATION -> getString(R.string.cat_police)
        OccurrenceType.ACCESS_BLOCKED -> getString(R.string.cat_blocked)
        OccurrenceType.ACCESS_DIFFICULTY -> getString(R.string.cat_access_difficulty)
    }
}
