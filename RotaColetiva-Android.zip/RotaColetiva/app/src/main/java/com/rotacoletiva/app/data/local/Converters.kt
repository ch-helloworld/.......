package com.rotacoletiva.app.data.local

import androidx.room.TypeConverter
import com.rotacoletiva.app.data.local.entities.OccurrenceType

/** Room can't persist enums natively, so we store them as their name string. */
class Converters {

    @TypeConverter
    fun fromOccurrenceType(value: OccurrenceType): String = value.name

    @TypeConverter
    fun toOccurrenceType(value: String): OccurrenceType = OccurrenceType.valueOf(value)
}
