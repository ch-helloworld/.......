package com.rotacoletiva.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import com.rotacoletiva.app.domain.GeoUtils
import com.rotacoletiva.app.location.LocationHelper
import kotlinx.coroutines.launch

sealed class RatingSubmitResult {
    object Success : RatingSubmitResult()
    object ErrorNoStar : RatingSubmitResult()
    object ErrorLocationUnavailable : RatingSubmitResult()
    object ErrorTooFar : RatingSubmitResult()
    object ErrorExpired : RatingSubmitResult()
}

class RatingViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as RotaColetivaApp).repository
    private val prefsManager = application.prefsManager
    private val locationHelper = LocationHelper(application)

    /** How far the driver's current GPS fix may be from the delivery's precise coordinate
     *  and still be allowed to rate it - wide enough for ordinary GPS drift, tight enough
     *  that rating a place you were never near is not possible. */
    private val maxDistanceMeters = 400.0

    /** How long after "starting" the delivery the rating window stays open - prevents
     *  backdated reports for a region long after the fact. */
    private val ratingWindowMillis = 60 * 60_000L // 1 hour

    private val _submitResult = MutableLiveData<RatingSubmitResult>()
    val submitResult: LiveData<RatingSubmitResult> = _submitResult

    fun submit(
        preciseLatitude: Double,
        preciseLongitude: Double,
        deliveryStartedAtMillis: Long,
        starRating: Int,
        selectedCategories: Set<OccurrenceType>
    ) {
        if (starRating <= 0) {
            _submitResult.value = RatingSubmitResult.ErrorNoStar
            return
        }

        if (System.currentTimeMillis() - deliveryStartedAtMillis > ratingWindowMillis) {
            _submitResult.value = RatingSubmitResult.ErrorExpired
            return
        }

        viewModelScope.launch {
            val currentLocation = locationHelper.getCurrentLocation()
            if (currentLocation == null) {
                _submitResult.value = RatingSubmitResult.ErrorLocationUnavailable
                return@launch
            }

            val distance = GeoUtils.distanceMeters(
                currentLocation.latitude, currentLocation.longitude,
                preciseLatitude, preciseLongitude
            )
            if (distance > maxDistanceMeters) {
                _submitResult.value = RatingSubmitResult.ErrorTooFar
                return@launch
            }

            // The category list is closed by design (no free text). A report needs at least
            // one category to be meaningful; default to CALM/INSECURITY based on the star
            // rating when the driver picks none. Each selected category becomes its own row
            // sharing the same location/time/rating, so multi-select reports are all counted
            // in the aggregate statistics rather than only the first one.
            val categories = selectedCategories.ifEmpty {
                setOf(if (starRating >= 4) OccurrenceType.CALM else OccurrenceType.INSECURITY)
            }

            for (category in categories) {
                repository.submitReport(
                    latitude = preciseLatitude,
                    longitude = preciseLongitude,
                    occurrenceType = category,
                    deliveryRating = starRating,
                    submittedBy = prefsManager.username ?: "anonimo"
                )
            }

            _submitResult.value = RatingSubmitResult.Success
        }
    }
}
