package com.rotacoletiva.app.util

import com.rotacoletiva.app.domain.GeoUtils

/**
 * Labels a coordinate with the nearest known neighborhood name, purely for display.
 * This is NOT a geocoding service - it only recognizes the handful of seeded regions.
 * A production build would replace this with reverse geocoding against OSM Nominatim;
 * kept local here to avoid an extra network dependency in the MVP.
 */
object RegionNamer {

    private data class Named(val name: String, val lat: Double, val lon: Double)

    private val known = listOf(
        Named("Campinho", -22.8823, -43.3287),
        Named("Praça Seca", -22.8974, -43.3346),
        Named("Marechal Hermes", -22.8613, -43.3560)
    )

    fun nameFor(latitude: Double, longitude: Double): String {
        val nearest = known.minByOrNull { GeoUtils.distanceMeters(latitude, longitude, it.lat, it.lon) }
        return if (nearest != null && GeoUtils.distanceMeters(latitude, longitude, nearest.lat, nearest.lon) <= 3_000) {
            nearest.name
        } else {
            "Região selecionada"
        }
    }
}
