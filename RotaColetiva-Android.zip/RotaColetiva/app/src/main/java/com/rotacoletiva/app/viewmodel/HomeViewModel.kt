package com.rotacoletiva.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.data.local.entities.DeliveryReport
import com.rotacoletiva.app.domain.RegionalStats
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = (application as RotaColetivaApp).repository

    private val _mapReports = MutableLiveData<List<DeliveryReport>>()
    val mapReports: LiveData<List<DeliveryReport>> = _mapReports

    private val _selectedRegionStats = MutableLiveData<RegionalStats?>()
    val selectedRegionStats: LiveData<RegionalStats?> = _selectedRegionStats

    fun loadMapReports() {
        viewModelScope.launch {
            _mapReports.value = repository.getRecentForMap()
        }
    }

    fun loadStatsForMarker(latitude: Double, longitude: Double) {
        viewModelScope.launch {
            _selectedRegionStats.value = repository.getStatsNear(latitude, longitude, repository.regionalRadiusMeters)
        }
    }

    fun clearSelection() {
        _selectedRegionStats.value = null
    }
}
