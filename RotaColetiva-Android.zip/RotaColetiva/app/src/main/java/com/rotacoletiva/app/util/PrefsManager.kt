package com.rotacoletiva.app.util

import android.content.Context
import android.content.SharedPreferences

/**
 * Thin wrapper around SharedPreferences. Login here is intentionally local-only (no backend,
 * no password) - it just lets the app tag each report with a name and remember the session,
 * as allowed by the brief ("login simples, pode ser fictício").
 */
class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var username: String?
        get() = prefs.getString(KEY_USERNAME, null)
        set(value) = prefs.edit().putString(KEY_USERNAME, value).apply()

    /** Whether the sample dataset has already been seeded into Room, so it only happens once. */
    var seeded: Boolean
        get() = prefs.getBoolean(KEY_SEEDED, false)
        set(value) = prefs.edit().putBoolean(KEY_SEEDED, value).apply()

    fun isLoggedIn(): Boolean = !username.isNullOrBlank()

    fun logout() {
        prefs.edit().remove(KEY_USERNAME).apply()
    }

    companion object {
        private const val PREFS_NAME = "rota_coletiva_prefs"
        private const val KEY_USERNAME = "username"
        private const val KEY_SEEDED = "seeded"
    }
}
