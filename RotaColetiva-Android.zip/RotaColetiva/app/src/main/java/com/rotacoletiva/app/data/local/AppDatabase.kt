package com.rotacoletiva.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.rotacoletiva.app.data.local.dao.DeliveryReportDao
import com.rotacoletiva.app.data.local.entities.DeliveryReport

@Database(entities = [DeliveryReport::class], version = 1, exportSchema = false)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun deliveryReportDao(): DeliveryReportDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "rota_coletiva.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
