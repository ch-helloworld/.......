package com.rotacoletiva.app.ui.offer

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AppCompatActivity
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.databinding.ActivityOfferBinding
import com.rotacoletiva.app.overlay.OverlayService
import com.rotacoletiva.app.ui.detail.DetailActivity
import com.rotacoletiva.app.util.IntentKeys
import com.rotacoletiva.app.util.PermissionUtils
import kotlin.random.Random

/**
 * Stands in for "a delivery offer appearing on the driver's screen". In production this
 * moment would be detected by [com.rotacoletiva.app.overlay.OfferAccessibilityService];
 * here the user triggers it manually from Home to demo the same downstream flow.
 */
class OfferActivity : AppCompatActivity() {

    private lateinit var binding: ActivityOfferBinding
    private var countDownTimer: CountDownTimer? = null

    // The "region" the driver sees before accepting - approximate on purpose.
    private var offerLat = 0.0
    private var offerLon = 0.0

    // The exact address, which a real delivery app only reveals after acceptance.
    private var preciseLat = 0.0
    private var preciseLon = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityOfferBinding.inflate(layoutInflater)
        setContentView(binding.root)

        generateSimulatedOfferLocation()
        startOverlayHud()
        startCountdown()

        binding.buttonAccept.setOnClickListener { acceptOffer() }
    }

    private fun generateSimulatedOfferLocation() {
        val clusters = listOf(
            -22.8823 to -43.3287, // Campinho
            -22.8974 to -43.3346, // Praça Seca
            -22.8613 to -43.3560  // Marechal Hermes
        )
        val (baseLat, baseLon) = clusters.random()
        // Pre-accept: only the wider region is known.
        offerLat = baseLat + (Random.nextDouble() - 0.5) * 0.006
        offerLon = baseLon + (Random.nextDouble() - 0.5) * 0.006
        // Post-accept: a precise address a little further inside the same neighborhood.
        preciseLat = offerLat + (Random.nextDouble() - 0.5) * 0.002
        preciseLon = offerLon + (Random.nextDouble() - 0.5) * 0.002
    }

    private fun startOverlayHud() {
        if (!PermissionUtils.hasOverlayPermission(this)) return
        val repository = (application as RotaColetivaApp).repository
        startService(OverlayService.showIntent(this, offerLat, offerLon, repository.regionalRadiusMeters))
    }

    private fun startCountdown() {
        countDownTimer = object : CountDownTimer(60_000, 1_000) {
            override fun onTick(millisUntilFinished: Long) {
                val secondsLeft = (millisUntilFinished / 1000).toInt()
                binding.textTimer.text = getString(com.rotacoletiva.app.R.string.offer_timer, secondsLeft)
            }

            override fun onFinish() {
                stopOverlay()
                finish() // Offer "expired" - back to Home, nothing recorded.
            }
        }.start()
    }

    private fun acceptOffer() {
        countDownTimer?.cancel()
        stopOverlay()
        val intent = Intent(this, DetailActivity::class.java).apply {
            putExtra(IntentKeys.EXTRA_LATITUDE, offerLat)
            putExtra(IntentKeys.EXTRA_LONGITUDE, offerLon)
            putExtra(IntentKeys.EXTRA_PRECISE_LATITUDE, preciseLat)
            putExtra(IntentKeys.EXTRA_PRECISE_LONGITUDE, preciseLon)
        }
        startActivity(intent)
        finish()
    }

    private fun stopOverlay() {
        startService(OverlayService.hideIntent(this))
    }

    override fun onDestroy() {
        super.onDestroy()
        countDownTimer?.cancel()
    }
}
