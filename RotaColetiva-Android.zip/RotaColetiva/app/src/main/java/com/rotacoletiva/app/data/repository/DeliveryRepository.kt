package com.rotacoletiva.app.data.repository

import com.rotacoletiva.app.data.local.dao.DeliveryReportDao
import com.rotacoletiva.app.data.local.entities.DeliveryReport
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import com.rotacoletiva.app.data.remote.RemoteSyncGateway
import com.rotacoletiva.app.domain.GeoUtils
import com.rotacoletiva.app.domain.RegionalStats
import com.rotacoletiva.app.domain.StatsCalculator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Single entry point the ViewModels talk to. Hides both the local Room database and the
 * (currently no-op) remote sync gateway behind one API, so swapping in a real backend later
 * only means changing what's injected here, not the call sites.
 */
class DeliveryRepository(
    private val dao: DeliveryReportDao,
    private val remoteSyncGateway: RemoteSyncGateway
) {

    /** Wide regional radius used for the pre-accept HUD, where only an approximate area is known. */
    val regionalRadiusMeters = 1_500.0

    /** Tight radius used once the exact delivery address is known, after accepting the offer. */
    val preciseRadiusMeters = 300.0

    suspend fun submitReport(
        latitude: Double,
        longitude: Double,
        occurrenceType: OccurrenceType,
        deliveryRating: Int,
        submittedBy: String
    ): Long = withContext(Dispatchers.IO) {
        dao.insert(
            DeliveryReport(
                latitude = latitude,
                longitude = longitude,
                timestampMillis = System.currentTimeMillis(),
                occurrenceType = occurrenceType,
                deliveryRating = deliveryRating.coerceIn(1, 5),
                submittedBy = submittedBy
            )
        )
    }

    suspend fun getStatsNear(latitude: Double, longitude: Double, radiusMeters: Double): RegionalStats =
        withContext(Dispatchers.IO) {
            val reportsInRadius = reportsWithin(latitude, longitude, radiusMeters)
            StatsCalculator.compute(reportsInRadius)
        }

    suspend fun getCategoryBreakdownNear(latitude: Double, longitude: Double, radiusMeters: Double): List<Pair<OccurrenceType, Int>> =
        withContext(Dispatchers.IO) {
            val reportsInRadius = reportsWithin(latitude, longitude, radiusMeters)
            StatsCalculator.computeCategoryBreakdown(reportsInRadius)
        }

    /** All reports within an exact radius (bounding box pre-filter + precise Haversine check). */
    private suspend fun reportsWithin(latitude: Double, longitude: Double, radiusMeters: Double): List<DeliveryReport> {
        val box = GeoUtils.boundingBox(latitude, longitude, radiusMeters)
        val candidates = dao.getInBoundingBox(box.minLat, box.maxLat, box.minLon, box.maxLon)
        return candidates.filter { report ->
            GeoUtils.distanceMeters(latitude, longitude, report.latitude, report.longitude) <= radiusMeters
        }
    }

    suspend fun getRecentForMap(limit: Int = 300): List<DeliveryReport> = withContext(Dispatchers.IO) {
        dao.getRecent(limit)
    }

    suspend fun getHistoryFor(username: String, limit: Int = 20): List<DeliveryReport> = withContext(Dispatchers.IO) {
        dao.getBySubmitter(username, limit)
    }

    suspend fun reportCount(): Int = withContext(Dispatchers.IO) { dao.count() }

    /** Reports not yet pushed to a remote backend. No-op today, but ready for a sync worker. */
    suspend fun getUnsyncedReports(): List<DeliveryReport> = withContext(Dispatchers.IO) { dao.getUnsynced() }

    suspend fun syncPendingReports(): Result<Int> = remoteSyncGateway.pushUnsynced(getUnsyncedReports())
}
