package com.rotacoletiva.app.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import com.rotacoletiva.app.util.PermissionUtils
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Deliberately uses the platform LocationManager instead of Google Play Services' fused
 * location provider. The brief explicitly avoids the Google Maps stack, and staying off
 * Play Services entirely keeps the location + map layers consistent and dependency-light.
 */
class LocationHelper(private val context: Context) {

    /**
     * Returns the best available fix: last-known location if it's fresh enough, otherwise
     * waits briefly for a single live update. Returns null if location can't be obtained
     * (permission missing, GPS off, or timeout) - callers must treat null as "unknown",
     * never assume a location.
     */
    @SuppressLint("MissingPermission")
    suspend fun getCurrentLocation(freshnessWindowMillis: Long = 2 * 60_000L, timeoutMillis: Long = 8_000L): Location? {
        if (!PermissionUtils.hasLocationPermission(context)) return null

        val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
            ?: return null

        val lastKnown = bestLastKnown(locationManager)
        if (lastKnown != null && System.currentTimeMillis() - lastKnown.time <= freshnessWindowMillis) {
            return lastKnown
        }

        return requestSingleUpdate(locationManager, timeoutMillis) ?: lastKnown
    }

    private fun bestLastKnown(locationManager: LocationManager): Location? {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        return providers.mapNotNull {
            try {
                locationManager.getLastKnownLocation(it)
            } catch (e: SecurityException) {
                null
            }
        }.maxByOrNull { it.time }
    }

    @SuppressLint("MissingPermission")
    private suspend fun requestSingleUpdate(locationManager: LocationManager, timeoutMillis: Long): Location? =
        suspendCancellableCoroutine { continuation ->
            val provider = when {
                locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> null
            }

            if (provider == null) {
                continuation.resume(null)
                return@suspendCancellableCoroutine
            }

            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    locationManager.removeUpdates(this)
                    if (continuation.isActive) continuation.resume(location)
                }
            }

            try {
                locationManager.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
            } catch (e: SecurityException) {
                continuation.resume(null)
                return@suspendCancellableCoroutine
            }

            continuation.invokeOnCancellation { locationManager.removeUpdates(listener) }

            android.os.Handler(Looper.getMainLooper()).postDelayed({
                locationManager.removeUpdates(listener)
                if (continuation.isActive) continuation.resume(null)
            }, timeoutMillis)
        }
}
