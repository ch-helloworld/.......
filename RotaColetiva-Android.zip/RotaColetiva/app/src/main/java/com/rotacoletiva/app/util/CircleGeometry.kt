package com.rotacoletiva.app.util

import org.osmdroid.util.GeoPoint
import kotlin.math.cos
import kotlin.math.sin

/** OSMDroid has no built-in "draw a circle in meters" overlay, so we approximate one as a
 *  many-sided polygon - visually indistinguishable from a circle at normal zoom levels. */
object CircleGeometry {

    fun circlePoints(centerLat: Double, centerLon: Double, radiusMeters: Double, sides: Int = 60): List<GeoPoint> {
        val earthRadius = 6_371_000.0
        val points = mutableListOf<GeoPoint>()
        for (i in 0..sides) {
            val angle = 2.0 * Math.PI * i / sides
            val dLat = (radiusMeters * cos(angle)) / earthRadius
            val dLon = (radiusMeters * sin(angle)) / (earthRadius * cos(Math.toRadians(centerLat)))
            points.add(GeoPoint(centerLat + Math.toDegrees(dLat), centerLon + Math.toDegrees(dLon)))
        }
        return points
    }
}
