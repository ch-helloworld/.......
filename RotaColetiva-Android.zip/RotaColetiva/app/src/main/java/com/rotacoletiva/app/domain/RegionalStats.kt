package com.rotacoletiva.app.domain

/**
 * Everything the UI needs to render a stats panel (HUD or detail screen).
 * Deliberately contains no verdict field - only counts and percentages.
 */
data class RegionalStats(
    val totalReports: Int,
    val pctCalm: Int,
    val pctInsecurity: Int,
    val pctSerious: Int,
    val lastReportMillis: Long?,
    val confidence: ConfidenceLevel
) {
    companion object {
        fun empty() = RegionalStats(
            totalReports = 0,
            pctCalm = 0,
            pctInsecurity = 0,
            pctSerious = 0,
            lastReportMillis = null,
            confidence = ConfidenceLevel.LOW
        )
    }
}
