package com.rotacoletiva.app.overlay

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.rotacoletiva.app.R
import com.rotacoletiva.app.RotaColetivaApp
import com.rotacoletiva.app.ui.home.HomeActivity
import com.rotacoletiva.app.util.IntentKeys
import com.rotacoletiva.app.util.RegionNamer
import com.rotacoletiva.app.util.StatsCardBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Foreground service that draws the small statistics window over whatever app is in the
 * foreground (simulated, in this MVP, by [com.rotacoletiva.app.ui.offer.OfferActivity]).
 *
 * The window opens immediately in a "scanning" state and swaps to real numbers roughly
 * 1-1.5s later, matching the brief's requirement that the panel must never delay the
 * driver's decision.
 */
class OverlayService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob())
    private var currentJob: Job? = null

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())

        when (intent?.action) {
            IntentKeys.ACTION_HIDE_OVERLAY -> {
                removeOverlay()
                stopSelf()
            }
            else -> {
                val lat = intent?.getDoubleExtra(IntentKeys.EXTRA_LATITUDE, Double.NaN) ?: Double.NaN
                val lon = intent?.getDoubleExtra(IntentKeys.EXTRA_LONGITUDE, Double.NaN) ?: Double.NaN
                val radius = intent?.getDoubleExtra(IntentKeys.EXTRA_RADIUS_METERS, 1_500.0) ?: 1_500.0
                if (!lat.isNaN() && !lon.isNaN()) {
                    showOverlay(lat, lon, radius)
                }
            }
        }

        return START_NOT_STICKY
    }

    private fun showOverlay(latitude: Double, longitude: Double, radiusMeters: Double) {
        if (overlayView == null) {
            addOverlayView()
        }
        val card = overlayView ?: return
        StatsCardBinder.showScanning(card)

        currentJob?.cancel()
        currentJob = serviceScope.launch {
            // Deliberately quick: the brief requires the HUD to appear in ~1-2s, never delaying
            // the ~60s the driver has to accept or reject the offer.
            delay(1300)
            val repository = (application as RotaColetivaApp).repository
            val stats = repository.getStatsNear(latitude, longitude, radiusMeters)
            val label = RegionNamer.nameFor(latitude, longitude)
            StatsCardBinder.bind(card, label, stats)
        }
    }

    private fun addOverlayView() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm

        val view = LayoutInflater.from(this).inflate(R.layout.view_stats_card, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.BOTTOM
        params.x = 0
        params.y = 220
        params.horizontalMargin = 0.04f

        try {
            wm.addView(view, params)
            overlayView = view
        } catch (e: SecurityException) {
            // SYSTEM_ALERT_WINDOW not granted - nothing we can draw. The Home/Permissions
            // screens are responsible for prompting the user before this point is reached.
        }
    }

    private fun removeOverlay() {
        currentJob?.cancel()
        val wm = windowManager
        val view = overlayView
        if (wm != null && view != null) {
            try {
                wm.removeView(view)
            } catch (e: IllegalArgumentException) {
                // View was already removed (e.g. service killed and restarted) - safe to ignore.
            }
        }
        overlayView = null
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        serviceScope.cancel()
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "overlay_service_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notif_channel_name),
                NotificationManager.IMPORTANCE_MIN
            )
            manager.createNotificationChannel(channel)
        }

        val contentIntent = PendingIntent.getActivity(
            this, 0, Intent(this, HomeActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notif_service_title))
            .setContentText(getString(R.string.notif_service_text))
            .setContentIntent(contentIntent)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 42

        fun showIntent(context: Context, latitude: Double, longitude: Double, radiusMeters: Double): Intent =
            Intent(context, OverlayService::class.java).apply {
                putExtra(IntentKeys.EXTRA_LATITUDE, latitude)
                putExtra(IntentKeys.EXTRA_LONGITUDE, longitude)
                putExtra(IntentKeys.EXTRA_RADIUS_METERS, radiusMeters)
            }

        fun hideIntent(context: Context): Intent =
            Intent(context, OverlayService::class.java).apply {
                action = IntentKeys.ACTION_HIDE_OVERLAY
            }
    }
}
