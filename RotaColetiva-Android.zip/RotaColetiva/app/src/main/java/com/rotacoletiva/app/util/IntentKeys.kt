package com.rotacoletiva.app.util

object IntentKeys {
    const val EXTRA_LATITUDE = "extra_latitude"
    const val EXTRA_LONGITUDE = "extra_longitude"
    const val EXTRA_RADIUS_METERS = "extra_radius_meters"
    const val EXTRA_PRECISE_LATITUDE = "extra_precise_latitude"
    const val EXTRA_PRECISE_LONGITUDE = "extra_precise_longitude"
    const val EXTRA_DELIVERY_STARTED_AT = "extra_delivery_started_at"

    const val ACTION_SHOW_OVERLAY = "com.rotacoletiva.app.action.SHOW_OVERLAY"
    const val ACTION_HIDE_OVERLAY = "com.rotacoletiva.app.action.HIDE_OVERLAY"
}
