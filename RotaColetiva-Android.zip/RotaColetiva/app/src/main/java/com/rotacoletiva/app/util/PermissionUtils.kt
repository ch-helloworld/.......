package com.rotacoletiva.app.util

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat

object PermissionUtils {

    fun hasLocationPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, android.Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED

    fun hasNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true // Not a runtime permission before Android 13
        }
    }

    fun hasOverlayPermission(context: Context): Boolean = Settings.canDrawOverlays(context)

    /**
     * Accessibility services can't be enabled programmatically - the user must flip them on
     * in system settings. This checks the system's list of currently-enabled services for ours.
     */
    fun isAccessibilityServiceEnabled(context: Context, serviceClassName: String): Boolean {
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val expected = "${context.packageName}/$serviceClassName"
        return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    fun allEssentialPermissionsGranted(context: Context, accessibilityServiceClassName: String): Boolean =
        hasLocationPermission(context) &&
            hasNotificationPermission(context) &&
            hasOverlayPermission(context) &&
            isAccessibilityServiceEnabled(context, accessibilityServiceClassName)
}
