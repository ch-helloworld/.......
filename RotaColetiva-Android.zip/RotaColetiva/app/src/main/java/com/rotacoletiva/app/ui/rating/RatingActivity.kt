package com.rotacoletiva.app.ui.rating

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import com.google.android.material.chip.Chip
import com.rotacoletiva.app.R
import com.rotacoletiva.app.data.local.entities.OccurrenceType
import com.rotacoletiva.app.databinding.ActivityRatingBinding
import com.rotacoletiva.app.ui.home.HomeActivity
import com.rotacoletiva.app.util.IntentKeys
import com.rotacoletiva.app.viewmodel.RatingSubmitResult
import com.rotacoletiva.app.viewmodel.RatingViewModel

class RatingActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRatingBinding
    private lateinit var viewModel: RatingViewModel

    private var preciseLat = 0.0
    private var preciseLon = 0.0
    private var deliveryStartedAt = 0L

    private val categoryTypes = listOf(
        OccurrenceType.CALM,
        OccurrenceType.INSECURITY,
        OccurrenceType.THIRD_PARTY_APPROACH,
        OccurrenceType.CONFRONTATION,
        OccurrenceType.POLICE_OPERATION,
        OccurrenceType.ACCESS_BLOCKED,
        OccurrenceType.ACCESS_DIFFICULTY
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRatingBinding.inflate(layoutInflater)
        setContentView(binding.root)

        preciseLat = intent.getDoubleExtra(IntentKeys.EXTRA_PRECISE_LATITUDE, Double.NaN)
        preciseLon = intent.getDoubleExtra(IntentKeys.EXTRA_PRECISE_LONGITUDE, Double.NaN)
        deliveryStartedAt = intent.getLongExtra(IntentKeys.EXTRA_DELIVERY_STARTED_AT, System.currentTimeMillis())

        if (preciseLat.isNaN() || preciseLon.isNaN()) {
            finish()
            return
        }

        viewModel = ViewModelProvider(this)[RatingViewModel::class.java]

        buildCategoryChips()
        setupRatingBar()
        setupSubmit()
        observeViewModel()
    }

    private fun buildCategoryChips() {
        for (type in categoryTypes) {
            val chip = Chip(this).apply {
                text = labelFor(type)
                isCheckable = true
                tag = type
                chipBackgroundColor = androidx.core.content.ContextCompat.getColorStateList(
                    context, R.color.asphalt_1
                )
                setTextColor(androidx.core.content.ContextCompat.getColor(context, R.color.ink_2))
                chipStrokeColor = androidx.core.content.ContextCompat.getColorStateList(context, R.color.hairline)
                chipStrokeWidth = 1f
            }
            binding.categoryChipGroup.addView(chip)
        }
    }

    private fun setupRatingBar() {
        binding.ratingBar.setOnRatingBarChangeListener { _, rating, _ ->
            binding.textStarCaption.text = captionFor(rating.toInt())
        }
    }

    private fun captionFor(stars: Int): String = when (stars) {
        1 -> "★ · ocorrência grave"
        2 -> "★★ · sensação de insegurança"
        3 -> "★★★ · pequenos problemas"
        4 -> "★★★★ · entrega tranquila"
        5 -> "★★★★★ · entrega tranquila"
        else -> ""
    }

    private fun setupSubmit() {
        binding.buttonSubmit.setOnClickListener {
            binding.textError.visibility = View.GONE
            val selected = binding.categoryChipGroup.checkedChipIds
                .mapNotNull { id -> binding.categoryChipGroup.findViewById<Chip>(id)?.tag as? OccurrenceType }
                .toSet()

            viewModel.submit(
                preciseLatitude = preciseLat,
                preciseLongitude = preciseLon,
                deliveryStartedAtMillis = deliveryStartedAt,
                starRating = binding.ratingBar.rating.toInt(),
                selectedCategories = selected
            )
        }
    }

    private fun observeViewModel() {
        viewModel.submitResult.observe(this) { result ->
            when (result) {
                is RatingSubmitResult.Success -> {
                    Toast.makeText(this, R.string.rating_success, Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this, HomeActivity::class.java))
                    finish()
                }
                is RatingSubmitResult.ErrorNoStar -> showError(R.string.rating_error_no_star)
                is RatingSubmitResult.ErrorLocationUnavailable -> showError(R.string.rating_error_location_unavailable)
                is RatingSubmitResult.ErrorTooFar -> showError(R.string.rating_error_too_far)
                is RatingSubmitResult.ErrorExpired -> showError(R.string.rating_error_expired)
            }
        }
    }

    private fun showError(resId: Int) {
        binding.textError.setText(resId)
        binding.textError.visibility = View.VISIBLE
    }

    private fun labelFor(type: OccurrenceType): String = when (type) {
        OccurrenceType.CALM -> getString(R.string.cat_calm)
        OccurrenceType.INSECURITY -> getString(R.string.cat_insecurity)
        OccurrenceType.THIRD_PARTY_APPROACH -> getString(R.string.cat_approach)
        OccurrenceType.CONFRONTATION -> getString(R.string.cat_confrontation)
        OccurrenceType.POLICE_OPERATION -> getString(R.string.cat_police)
        OccurrenceType.ACCESS_BLOCKED -> getString(R.string.cat_blocked)
        OccurrenceType.ACCESS_DIFFICULTY -> getString(R.string.cat_access_difficulty)
    }
}
