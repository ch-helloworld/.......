package com.rotacoletiva.app.data.remote

import com.rotacoletiva.app.data.local.entities.DeliveryReport

/**
 * Extension point for a future online backend (Firebase, Supabase, or a custom API).
 *
 * The MVP ships only [NoOpRemoteSyncGateway], which keeps everything local. When a real
 * backend is ready, implement this interface (e.g. `FirebaseSyncGateway`), swap the
 * instance created in `RotaColetivaApp`, and wire a periodic WorkManager job that calls
 * [pushUnsynced] with whatever `DeliveryRepository.getUnsyncedReports()` returns.
 * No changes to the database schema or UI are required for this migration.
 */
interface RemoteSyncGateway {
    suspend fun pushUnsynced(reports: List<DeliveryReport>): Result<Int>
}

/** Default implementation for the MVP: the app works fully offline-first, nothing is sent anywhere. */
class NoOpRemoteSyncGateway : RemoteSyncGateway {
    override suspend fun pushUnsynced(reports: List<DeliveryReport>): Result<Int> {
        return Result.success(0)
    }
}
